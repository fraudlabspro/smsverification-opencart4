<?php
namespace Opencart\Catalog\Model\Extension\Fraudlabsprosmsverification\Fraud;
class Fraudlabsprosmsverification extends \Opencart\System\Engine\Model {
	public function check(array $data): int {
		return 0;
	}

}